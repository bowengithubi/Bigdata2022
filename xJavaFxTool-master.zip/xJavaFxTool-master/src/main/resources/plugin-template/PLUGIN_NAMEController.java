package [PACKAGE];

public class [CLASS_NAME] {

}