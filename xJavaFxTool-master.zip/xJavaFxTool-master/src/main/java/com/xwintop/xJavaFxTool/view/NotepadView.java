package com.xwintop.xJavaFxTool.view;

import javafx.fxml.FXML;
import javafx.scene.control.TabPane;

public abstract class NotepadView {

    @FXML
    protected TabPane tabPane;
}
