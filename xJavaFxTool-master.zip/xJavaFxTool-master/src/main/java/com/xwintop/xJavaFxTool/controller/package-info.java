/**   
 * Copyright © 2017 公司名. All rights reserved.
 * 
 * @Title: package-info.java 
 * @Prject: xJavaFxTool
 * @Package: com.xwintop.xJavaFxTool.controller 
 * @Description: 视图控制层包
 * @author: xufeng   
 * @date: 2017年7月20日 上午9:11:11 
 * @version: V1.0   
 */
package com.xwintop.xJavaFxTool.controller;