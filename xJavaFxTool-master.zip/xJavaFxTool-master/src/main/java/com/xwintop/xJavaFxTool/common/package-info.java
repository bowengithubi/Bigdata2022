/**   
 * Copyright © 2017 公司名. All rights reserved.
 * 
 * @Title: package-info.java 
 * @Prject: xJavaFxTool
 * @Package: com.xwintop.xJavaFxTool.common 
 * @Description: 公共工具包
 * @author: xufeng   
 * @date: 2017年8月3日 上午8:37:58 
 * @version: V1.0   
 */
package com.xwintop.xJavaFxTool.common;