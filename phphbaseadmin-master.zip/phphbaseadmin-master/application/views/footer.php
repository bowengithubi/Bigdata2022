<hr></hr>
		<center>Copyright ShiDongJie under GPLv3 license, Don't Remove this line, Runtime: <?php echo $this->benchmark->elapsed_time();?></center>
<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1000072911'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s22.cnzz.com/z_stat.php%3Fid%3D1000072911%26show%3Dpic1' type='text/javascript'%3E%3C/script%3E"));</script>
	</body>
</html>