<div class="span2 rmonitor" style="height: 600px;">

    <ul class="nav nav-list">
          <li class="nav-header">Admin</li>
          <li class="active"><li><a href="<?php echo $this->config->base_url();?>index.php/monitor/zookeeper/"><i class="icon-cog"></i> Cluster Config</a></li>
          <li class="divider"></li>
          <li class="nav-header">ZooKeeper Monitor</li>          
          <li><a href="<?php echo $this->config->base_url();?>index.php/monitor/cluster_monitor/"><i class="icon-search"></i> Cluster Monitor</a></li>
                           
          <li class="divider"></li>
          <li><a href="<?php echo $this->config->base_url();?>index.php/monitor/zkmonitor_help/"><i class="icon-book"></i> Help</a></li>
        </ul>
   
</div>