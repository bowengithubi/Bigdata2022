<?php

$configure = array();
$configure['hbase_host'] = '127.0.0.1';
$configure['hbase_port'] = '9090';
$configure['hbaseadmin_port'] = '60010';
$configure['cherrypy_host'] = '192.168.205.208';
$configure['cherrypy_port'] = '2080';
$configure['language'] = 'english';
?>
