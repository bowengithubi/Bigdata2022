## Zookeeper可视化客户端ZooViewer

Zookeeper的可视化客户端工具，可以对集群中数据节点进行查看和操作。

详细使用教程链接：[https://blog.csdn.net/u010889616/article/details/80792912](https://blog.csdn.net/u010889616/article/details/80792912)

## 基本功能
- 实时显示Zookeeper集群节点数据
- 查看节点数据
- 更新节点数据值
- 删除节点
- 添加节点

## 界面展示
#### 登录界面
![](https://i.imgur.com/e6Ftest.png)

#### 主界面
![](https://i.imgur.com/Na0oiBF.png)



