HdfsTool

![hdfsTool.png](images/hdfsTool.png)